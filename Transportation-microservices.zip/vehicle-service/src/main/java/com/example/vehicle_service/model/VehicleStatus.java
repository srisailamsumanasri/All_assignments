
package com.example.vehicle_service.model;

public enum VehicleStatus {
    AVAILABLE, ON_TRIP, MAINTENANCE
}
